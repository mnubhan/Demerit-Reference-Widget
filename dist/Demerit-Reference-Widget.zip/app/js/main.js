import initializeWidget from "./custom.js";

initializeWidget();