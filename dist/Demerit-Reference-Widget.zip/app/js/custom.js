import createRowTable from "./createRowTable.js";
function initializeWidget() {
  /*
   * Subscribe to the EmbeddedApp onPageLoad event before initializing the widget
   */
  ZOHO.embeddedApp.on("PageLoad", () => {
    ZOHO.CRM.API.getAllRecords({ Entity: "Leads" }).then((result) => {
      createRowTable(result.data);
    });
  });
  ZOHO.embeddedApp.init();
}

export default initializeWidget;
